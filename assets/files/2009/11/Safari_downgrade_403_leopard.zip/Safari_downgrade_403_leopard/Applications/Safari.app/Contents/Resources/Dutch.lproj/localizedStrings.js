﻿


var localizedStrings = new Object;

localizedStrings["About Safari"] = "Over Safari";
localizedStrings["Copyright © 2007-2009 Apple Inc. All rights reserved."] = "Copyright © 2007-2009 Apple Inc. Alle rechten voorbehouden.";

localizedStrings["Advanced"] = "Geavanceerd";
localizedStrings["Universal Access:"] = "Universele toegang:";
localizedStrings["Never use font sizes smaller than"] = "Nooit een lettergrootte gebruiken kleiner dan";
localizedStrings["Press Tab to highlight each item on a webpage"] = "Tab-toets markeert elk onderdeel op webpagina";
localizedStrings["Style sheet:"] = "Opmaaksjabloon:";
localizedStrings["Proxies:"] = "Proxy's:";
localizedStrings["Open the Internet Options Control Panel to change your proxy settings"] = "Hiermee opent u het configuratiescherm 'Internetopties' om de proxy-instellingen te wijzigen.";
localizedStrings["Change Settings…"] = "Instellingen wijzigen…";
localizedStrings["Show Develop menu in menu bar"] = "Ontwikkel-menu in menubalk tonen";

localizedStrings["Cancel"] = "Annuleren";
localizedStrings["Done"] = "Gereed";

localizedStrings["Appearance"] = "Weergave";
localizedStrings["Standard font:"] = "Standaardlettertype:";
localizedStrings["Select the font to use when a web page doesn’t specify a font."] = "Hiermee geeft u op welk lettertype moet worden gebruikt als dit niet is gedefinieerd in de webpagina.";
localizedStrings["Select…"] = "Selecteren…";
localizedStrings["Fixed-width font:"] = "Niet-proportioneel lettertype:";
localizedStrings["Select the font to use when a web page specifies a fixed-width font."] = "Hiermee geeft u op welk lettertype moet worden gebruikt als een webpagina gebruikmaakt van een niet-proportioneel lettertype.";
localizedStrings["Font smoothing:"] = "Betere tekstweergave:";

localizedStrings["Best for CRT"] = "Beste voor CRT-beeldschermen";
localizedStrings["Light"] = "Licht";
localizedStrings["Medium - best for Flat Panel"] = "Gemiddeld - beste voor flat-panelbeeldschermen";
localizedStrings["Strong"] = "Sterk";
localizedStrings["Windows Standard"] = "Windows-standaard";
localizedStrings["Display images when the page opens"] = "Afbeeldingen weergeven wanneer de pagina wordt geopend";
localizedStrings["Default encoding:"] = "Standaardcodering:";

localizedStrings["AutoFill"] = "Formulieren";
localizedStrings["AutoFill web forms:"] = "Automatische invulling van webformulieren:";
localizedStrings["Using info from my Address Book card"] = "Op basis van de gegevens in mijn Adresboek-kaart";
localizedStrings["Open Address Book to edit your card"] = "Hiermee opent u Adresboek om uw kaart te wijzigen.";
localizedStrings["Edit…"] = "Bewerken…";
localizedStrings["User names and passwords"] = "Gebruikersnamen en wachtwoorden";
localizedStrings["Remove saved names and passwords"] = "Bewaarde namen en wachtwoorden verwijderen";
localizedStrings["Other forms"] = "Andere formulieren";
localizedStrings["Remove websites with saved AutoFill information"] = "Hiermee verwijdert u websites met bewaarde automatisch ingevulde formulieren.";

localizedStrings["Bookmark Chooser"] = "Bladwijzerkiezer";
localizedStrings["Choose a folder or collection"] = "Kies een map of set";
localizedStrings["Choose"] = "Kiezen";

localizedStrings["Bookmarks"] = "Bladwijzers";
localizedStrings["Bookmarks bar:"] = "Bladwijzerbalk:";
localizedStrings["Include Address Book"] = "Adresboek toevoegen";
localizedStrings["Include Bonjour"] = "Bonjour toevoegen";
localizedStrings["Bookmarks menu:"] = "Bladwijzermenu:";
localizedStrings["Include bookmarks bar"] = "Bladwijzerbalk toevoegen";
localizedStrings["Collections:"] = "Sets:";
localizedStrings["Synchronize bookmarks using MobileMe"] = "Bladwijzers synchroniseren via MobileMe";
localizedStrings["MobileMe…"] = "MobileMe…";

localizedStrings["Type a name for the bookmark."] = "Typ een naam voor de bladwijzer.";
localizedStrings["OK"] = "OK";

localizedStrings["Report Bug"] = "Bug rapporteren";
localizedStrings["Page Address:"] = "Adres pagina:";
localizedStrings["Description:"] = "Beschrijving:";
localizedStrings["Problem type:"] = "Type probleem:";
localizedStrings["Unspecified"] = "Niet gespecificeerd";
localizedStrings["Crash"] = "Onverwacht gestopt";
localizedStrings["Can’t log in"] = "Inloggen mislukt";
localizedStrings["Can’t load page"] = "Laden van pagina mislukt";
localizedStrings["Blank page"] = "Lege pagina";
localizedStrings["Content missing"] = "Ontbrekende inhoud";
localizedStrings["Behavior wrong"] = "Onjuiste werking";
localizedStrings["Appearance wrong"] = "Onjuiste weergave";
localizedStrings["Other problem"] = "Ander probleem";
localizedStrings["Send screen shot of current page"] = "Schermafbeelding van huidige pagina versturen";
localizedStrings["Send source of current page"] = "Bronversie van huidige pagina versturen";

localizedStrings["General"] = "Algemeen";
localizedStrings["Default web browser:"] = "Standaardwebbrowser:";
localizedStrings["Default search engine:"] = "Standaardzoekmachine:";
localizedStrings["Google"] = "Google";
localizedStrings["Yahoo!"] = "Yahoo!";
localizedStrings["New windows open with:"] = "Open nieuwe vensters met:";
localizedStrings["New tabs open with:"] = "Open nieuwe tabbladen met:";
localizedStrings["Home Page"] = "Startpagina";
localizedStrings["Empty Page"] = "Lege pagina";
localizedStrings["Same Page"] = "Dezelfde pagina";
localizedStrings["Bookmarks"] = "Bladwijzers";
localizedStrings["Choose tabs folder…"] = "Tabbladenmap kiezen…";
localizedStrings["Home page:"] = "Startpagina:";
localizedStrings["Set to Current Page"] = "Instellen op huidige pagina";
localizedStrings["Remove history items:"] = "Onderdelen uit geschiedenis verwijderen:";
localizedStrings["After one day"] = "Na één dag";
localizedStrings["After one week"] = "Na één week";
localizedStrings["After two weeks"] = "Na twee weken";
localizedStrings["After one month"] = "Na één maand";
localizedStrings["After one year"] = "Na één jaar";
localizedStrings["Manually"] = "Handmatig";
localizedStrings["Save downloaded files to:"] = "Locatie gedownloade bestanden:";
localizedStrings["Other…"] = "Andere…";
localizedStrings["Always prompt before downloading"] = "Altijd vragen alvorens te downloaden";
localizedStrings["Prompting cannot be disabled for some high-risk file types, including applications."] = "Vragen kan niet worden uitgeschakeld voor bepaalde bestandstypen met een hoog risico, zoals programma's.";
localizedStrings["Remove download list items:"] = "Wis downloadlijst:";
localizedStrings["When Safari Quits"] = "Bij stoppen van Safari";
localizedStrings["Upon Successful Download"] = "Nadat het downloaden is geslaagd";
localizedStrings["Open “safe” files after downloading"] = "Open “veilige” bestanden na downloaden";
localizedStrings["“Safe” files include movies, pictures, sounds, PDF and text documents, and disk images and other archives."] = "“Veilige” bestanden zijn films, afbeeldingen, geluidsbestanden, pdf- en tekstdocumenten, schijfkopieën en andere archiefbestanden.";
localizedStrings["Open links from applications:"] = "Open programmakoppelingen:";
localizedStrings["in a new window"] = "in nieuw venster";
localizedStrings["in a new tab in the current window"] = "in nieuw tabblad in huidige venster";
localizedStrings["This applies to links from Mail, iChat, etc."] = "Van toepassing op koppelingen in Mail, iChat, enz.";
localizedStrings["This applies to links from Mail, etc."] = "Van toepassing op koppelingen in Mail, enz.";

localizedStrings["Reset Safari"] = "Safari opnieuw instellen";
localizedStrings["Are you sure you want to reset Safari?"] = "Weet u zeker dat u Safari opnieuw wilt instellen?";
localizedStrings["Select the items you want to reset, and then click Reset. You can’t undo this operation."] = "Selecteer de onderdelen die u opnieuw wilt instellen en klik op 'Opnieuw instellen'. Deze bewerking kan niet ongedaan worden gemaakt.";
localizedStrings["Clear history"] = "Geschiedenis wissen";
localizedStrings["Reset Top Sites"] = "Top Sites opnieuw instellen";
localizedStrings["Remove all webpage preview images"] = "Verwijder alle voorvertoningen van webpagina's";
localizedStrings["Empty the cache"] = "Cache leegmaken";
localizedStrings["Clear the Downloads window"] = "Downloadvenster wissen";
localizedStrings["Remove all cookies"] = "Alle cookies verwijderen";
localizedStrings["Remove all website icons"] = "Alle websitesymbolen verwijderen";
localizedStrings["Remove saved names and passwords"] = "Bewaarde namen en wachtwoorden verwijderen";
localizedStrings["Remove other AutoFill form text"] = "Andere automatisch ingevulde formuliertekst verwijderen";
localizedStrings["Close all Safari windows"] = "Alle Safari-vensters sluiten";
localizedStrings["Reset"] = "Opnieuw instellen";

localizedStrings["RSS"] = "RSS";
localizedStrings["Default RSS reader:"] = "Standaard-RSS-lezer:";
localizedStrings["Automatically update articles in:"] = "Artikelen automatisch bijwerken in:";
localizedStrings["Bookmarks bar"] = "Bladwijzerbalk";
localizedStrings["Bookmarks menu"] = "Bladwijzermenu";
localizedStrings["Check for updates:"] = "Zoeken naar updates:";
localizedStrings["Never"] = "Nooit";
localizedStrings["Every day"] = "Elke dag";
localizedStrings["Every hour"] = "Elk uur";
localizedStrings["Every 30 minutes"] = "Elk half uur";
localizedStrings["Mark articles as read:"] = "Markeer artikelen als gelezen:";
localizedStrings["After viewing the RSS page"] = "Nadat RSS-pagina is bekeken";
localizedStrings["After clicking them"] = "Nadat erop is geklikt";
localizedStrings["Highlight unread articles"] = "Niet-gelezen artikelen markeren";
localizedStrings["Remove articles:"] = "Artikelen verwijderen:";
localizedStrings["Remove Now"] = "Nu verwijderen";

localizedStrings["Security"] = "Beveiliging";
localizedStrings["Fraudulent sites:"] = "Frauduleuze sites:";
localizedStrings["Warn when visiting a fraudulent website"] = "Waarschuwen bij bezoeken van frauduleuze website";
localizedStrings["The Google Safe Browsing Service is unavailable."] = "De Google Safe Browsing Service is niet beschikbaar.";
localizedStrings["No updates have occurred in %@."] = "Gedurende %@ zijn er geen updates geweest.";
localizedStrings["Web content:"] = "Webmateriaal:";
localizedStrings["Enable plug-ins"] = "Plugins activeren";
localizedStrings["Enable Java"] = "Java activeren";
localizedStrings["Enable JavaScript"] = "JavaScript activeren";
localizedStrings["Block pop-up windows"] = "Pop-upvensters blokkeren";
localizedStrings["Accept cookies:"] = "Cookies accepteren:";
localizedStrings["Always"] = "Altijd";
localizedStrings["Only from sites I visit"] = "Alleen van sites die ik bezoek";
localizedStrings["Block cookies from third parties and advertisers."] = "Blokkeer cookies van andere fabrikanten en adverteerders.";
localizedStrings["Show Cookies"] = "Cookies tonen";
localizedStrings["Default space for database storage:"] = "Standaardruimte voor databaseopslag:";
localizedStrings["Show Databases"] = "Databases tonen";
localizedStrings["Ask before sending a non-secure form to a secure website"] = "Versturen van niet-beveiligd formulier naar beveiligde website bevestigen";

localizedStrings["1 minute"] = "1 minuut";
localizedStrings["%@ minutes"] = "%@ minuten";
localizedStrings["1 hour"] = "1 uur";
localizedStrings["%@ hours"] = "%@ uur";
localizedStrings["1 day"] = "1 dag";
localizedStrings["%@ days"] = "%@ dagen";
        
localizedStrings["Tabs"] = "Tabs";
localizedStrings["Ctrl-click opens a link in a new tab"] = "Koppeling in nieuw tabblad openen met Ctrl + klikken";
localizedStrings["When a new tab or window opens, make it active."] = "Nieuw tabblad of venster na openen actief maken";
localizedStrings["Confirm before closing multiple tabs or windows."] = "Vragen om bevestiging bij sluiten meerdere tabbladen of vensters";
localizedStrings["Ctrl-click:"] = "Ctrl + klikken:";
localizedStrings["Opens a link in a new tab, and makes it the active tab."] = "Koppeling in nieuw tabblad openen en dit het actieve tabblad maken.";
localizedStrings["Opens a link in a new tab."] = "Koppeling in nieuw tabblad openen.";
localizedStrings["Opens a link in a new window, and makes it the active window."] = "Koppeling in nieuw venster openen en dit het actieve venster maken.";
localizedStrings["Opens a link in a new window."] = "Koppeling in nieuw venster openen.";
localizedStrings["Ctrl-Shift-click:"] = "Ctrl + Shift + klikken:";
localizedStrings["Ctrl-Alt-click:"] = "Ctrl + Alt + klikken:";
localizedStrings["Ctrl-Alt-Shift-click:"] = "Ctrl + Alt + Shift + klikken:";

localizedStrings["Name:"] = "Naam:";
localizedStrings["Password:"] = "Wachtwoord:";
localizedStrings["Remember this password"] = "Dit wachtwoord onthouden";
localizedStrings["Log In"] = "Inloggen";

localizedStrings["File Download - Security Warning"] = "Bestandsdownload - beveiligingswaarschuwing";
localizedStrings["Do you want to open or save this file?"] = "Wilt u dit bestand openen of bewaren?";
localizedStrings["Always ask before downloading files of this type"] = "Altijd vragen alvorens dit type bestand te downloaden";
localizedStrings["Open"] = "Open";
localizedStrings["Save"] = "Opslaan";
localizedStrings["Name:"] = "Naam:";
localizedStrings["Type:"] = "Type:";
localizedStrings["From:"] = "Van:";

localizedStrings["Type a name for the bookmark, and choose where to keep it."] = "Typ een naam voor de bladwijzer en selecteer de gewenste locatie.";
localizedStrings["Add"] = "Toevoegen";

localizedStrings["Spelling and Grammar"] = "Spelling en grammatica";
localizedStrings["Ignore"] = "Negeren";
localizedStrings["Learn"] = "Toevoegen";
localizedStrings["Find Next"] = "Volgende zoeken";
localizedStrings["Change"] = "Wijzigen";
localizedStrings["Check grammar"] = "Grammatica controleren";

localizedStrings["Choose a Font"] = "Kies een lettertype:";
localizedStrings["Family"] = "Familie";
localizedStrings["Sample"] = "Voorbeeld";
localizedStrings["ABCDEFGHIJKLMNOPQRSTUVWXYZ"] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
localizedStrings["abcdefghijklmnopqrstuvwxyz"] = "abcdefghijklmnopqrstuvwxyz";
localizedStrings["1234567890"] = "1234567890";
localizedStrings["Size"] = "Vergroot/verklein";

localizedStrings["Drag your favorite items into the toolbar…"] = "Sleep uw favoriete onderdelen naar de knoppenbalk…";
localizedStrings["Back/Forward"] = "Vorige/Volgende";
localizedStrings["Top Sites"] = "Top Sites";
localizedStrings["Home"] = "Startpagina";
localizedStrings["Zoom"] = "Vergroten/verkleinen";
localizedStrings["Stop/Reload"] = "Stoppen/Opnieuw laden";
localizedStrings["Add Bookmark"] = "Bladwijzer toevoegen";
localizedStrings["Print"] = "Afdrukken";
localizedStrings["Address and Search"] = "Adres- en zoekveld";
localizedStrings["Add Bookmark, Address and Search"] = "Voeg bladwijzer toe, adresveld en zoekveld";
localizedStrings["…or drag the default set."] = "… of sleep de standaardset.";
localizedStrings["New Tab"] = "Nieuw tabblad";
localizedStrings["History"] = "Geschiedenis";
localizedStrings["Bookmarks"] = "Bladwijzers";
localizedStrings["Add Bookmark"] = "Bladwijzer toevoegen";
localizedStrings["Bookmarks Bar"] = "Bladwijzerbalk";
localizedStrings["Mail"] = "E-mail";
localizedStrings["Downloads"] = "Downloads";
localizedStrings["Web Inspector"] = "Webinfovenster";

localizedStrings["Warning: Visiting this site may harm your computer"] = "Let op: bezoek aan deze site kan uw computer beschadigen";
localizedStrings["Warning: Suspected phishing site"] = "Let op: mogelijke phishing-site";
localizedStrings["The website you are visiting appears to contain malware. Malware is malicious software that may harm your computer or otherwise operate without your consent. Your computer can be infected just by browsing to a site with malware, without any further action on your part."] = "De website die u bezoekt bevat waarschijnlijk malware. Malware is kwaadaardige software die uw computer kan beschadigen of zonder uw toestemming bewerkingen kan uitvoeren. Ook als u een website met malware alleen maar bezoekt zonder verder iets te doen kan malware op uw computer terechtkomen.";
localizedStrings["For detailed information about problems found on this site, or a portion of this site, visit the Google Safe Browsing diagnostic page for %@."] = "Voor uitgebreide informatie over de problemen die zijn aangetroffen op deze site, of delen van deze site, gaat u naar de Google Safe Browsing-pagina met diagnostische informatie voor %@.";
localizedStrings["The website you are visiting has been reported as a “phishing” website. These websites are designed to trick you into disclosing personal or financial information, usually by creating a copy of a legitimate website, such as a bank."] = "De website die u bezoekt is aangemerkt als een phishing-website. Dergelijke websites proberen via misleiding uw persoonlijke of financiële gegevens te achterhalen en zijn vaak een kopie van een echte website, bijvoorbeeld van een bank.";
localizedStrings["Learn more about phishing scams"] = "Meer informatie over misleiding via phishing";
localizedStrings["Ignore warning"] = "Waarschuwing negeren";
localizedStrings["Go Back"] = "Vorige";
localizedStrings["Close page"] = "Pagina sluiten";
localizedStrings["Report an error"] = "Een fout rapporteren";
localizedStrings["Suspected Phishing Site"] = "Vermoedelijke phishing-site";
localizedStrings["Suspected Malware Site"] = "Vermoedelijke malware-site";

localizedStrings["No matches"] = "Niets gevonden";
localizedStrings["1 match"] = "1 resultaat";
localizedStrings["%@ matches"] = "%@ resultaten gevonden";
localizedStrings["All"] = "Alles";
localizedStrings["Search:"] = "Zoeken:";
