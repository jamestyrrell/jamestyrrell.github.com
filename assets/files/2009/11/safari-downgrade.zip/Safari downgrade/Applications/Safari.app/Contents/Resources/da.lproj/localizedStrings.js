﻿


var localizedStrings = new Object;

localizedStrings["About Safari"] = "Om Safari";
localizedStrings["Copyright © 2007-2009 Apple Inc. All rights reserved."] = "Copyright © 2007-2009 Apple Inc. Alle rettigheder forbeholdes.";

localizedStrings["Advanced"] = "Avanceret";
localizedStrings["Universal Access:"] = "Universel adgang:";
localizedStrings["Never use font sizes smaller than"] = "Brug aldrig skrifter mindre end";
localizedStrings["Press Tab to highlight each item on a webpage"] = "Tryk på Tab for at fremhæve hvert emne på en webside";
localizedStrings["Style sheet:"] = "Skriftsnitark:";
localizedStrings["Proxies:"] = "Proxyservere:";
localizedStrings["Open the Internet Options Control Panel to change your proxy settings"] = "Åbn kontrolpanelet Internetindstillinger for at ændre proxyindstillinger";
localizedStrings["Change Settings…"] = "Skift indstillinger…";
localizedStrings["Show Develop menu in menu bar"] = "Vis Udviklermenuen på menulinjen";

localizedStrings["Cancel"] = "Annuller";
localizedStrings["Done"] = "OK";

localizedStrings["Appearance"] = "Udseende";
localizedStrings["Standard font:"] = "Standardskrift:";
localizedStrings["Select the font to use when a web page doesn’t specify a font."] = "Vælg den skrift, du vil bruge, når en webside ikke angiver en skrift.";
localizedStrings["Select…"] = "Vælg…";
localizedStrings["Fixed-width font:"] = "Fast skriftbredde:";
localizedStrings["Select the font to use when a web page specifies a fixed-width font."] = "Vælg den skrift, du vil bruge, når en webside angiver en skrift med fast bredde.";
localizedStrings["Font smoothing:"] = "Skriftudglatning:";

localizedStrings["Best for CRT"] = "Bedst til CRT";
localizedStrings["Light"] = "Lys";
localizedStrings["Medium - best for Flat Panel"] = "Medium - bedst til flad skærm";
localizedStrings["Strong"] = "Stærk";
localizedStrings["Windows Standard"] = "Windows-standard";
localizedStrings["Display images when the page opens"] = "Vis billeder, når siden åbnes.";
localizedStrings["Default encoding:"] = "Standardkodning:";

localizedStrings["AutoFill"] = "Auto-udfyld";
localizedStrings["AutoFill web forms:"] = "Auto-udfyld webformularer:";
localizedStrings["Using info from my Address Book card"] = "Brug info fra mit adressebogskort";
localizedStrings["Open Address Book to edit your card"] = "Åbn Adressebog for at redigere dit kort";
localizedStrings["Edit…"] = "Rediger…";
localizedStrings["User names and passwords"] = "Brugernavne og adgangskoder";
localizedStrings["Remove saved names and passwords"] = "Fjern arkiverede navne og adgangskoder";
localizedStrings["Other forms"] = "Andre formularer";
localizedStrings["Remove websites with saved AutoFill information"] = "Fjern websteder med indhold, der er arkiveret via Auto-udfyld";

localizedStrings["Bookmark Chooser"] = "Bogmærkevælger";
localizedStrings["Choose a folder or collection"] = "Vælg en mappe eller samling";
localizedStrings["Choose"] = "Vælg";

localizedStrings["Bookmarks"] = "Bogmærker";
localizedStrings["Bookmarks bar:"] = "Bogmærkelinje:";
localizedStrings["Include Address Book"] = "Inkluder adressebog";
localizedStrings["Include Bonjour"] = "Inkluder Bonjour";
localizedStrings["Bookmarks menu:"] = "Bogmærkemenu:";
localizedStrings["Include bookmarks bar"] = "Inkluder bogmærkelinje";
localizedStrings["Collections:"] = "Samlinger:";
localizedStrings["Synchronize bookmarks using MobileMe"] = "Synkroniser bogmærker med MobileMe";
localizedStrings["MobileMe…"] = "MobileMe…";

localizedStrings["Type a name for the bookmark."] = "Skriv et navn til bogmærket.";
localizedStrings["OK"] = "OK";

localizedStrings["Report Bug"] = "Rapporter fejl";
localizedStrings["Page Address:"] = "Sideadresse:";
localizedStrings["Description:"] = "Beskrivelse:";
localizedStrings["Problem type:"] = "Fejltype:";
localizedStrings["Unspecified"] = "Uspecificeret";
localizedStrings["Crash"] = "Systemsvigt";
localizedStrings["Can’t log in"] = "Kan ikke logge ind";
localizedStrings["Can’t load page"] = "Kan ikke åbne side";
localizedStrings["Blank page"] = "Tom side";
localizedStrings["Content missing"] = "Indhold mangler";
localizedStrings["Behavior wrong"] = "Forkert opførsel";
localizedStrings["Appearance wrong"] = "Udseendet er forkert";
localizedStrings["Other problem"] = "Anden fejl";
localizedStrings["Send screen shot of current page"] = "Send skærmbillede af aktuel side";
localizedStrings["Send source of current page"] = "Send kildekode af aktuel side";

localizedStrings["General"] = "Generelt";
localizedStrings["Default web browser:"] = "Standardbrowser:";
localizedStrings["Default search engine:"] = "Standardsøgeprogram:";
localizedStrings["Google"] = "Google";
localizedStrings["Yahoo!"] = "Yahoo!";
localizedStrings["New windows open with:"] = "Nye vinduer åbnes med:";
localizedStrings["New tabs open with:"] = "Nye faner åbnes med:";
localizedStrings["Home Page"] = "Hjemmeside";
localizedStrings["Empty Page"] = "Tom side";
localizedStrings["Same Page"] = "Samme side";
localizedStrings["Bookmarks"] = "Bogmærker";
localizedStrings["Choose tabs folder…"] = "Vælg en mappe med faner...";
localizedStrings["Home page:"] = "Hjemmeside:";
localizedStrings["Set to Current Page"] = "Indstil til aktuel side";
localizedStrings["Remove history items:"] = "Fjern historie:";
localizedStrings["After one day"] = "Efter en dag";
localizedStrings["After one week"] = "Efter en uge";
localizedStrings["After two weeks"] = "Efter to uger";
localizedStrings["After one month"] = "Efter en måned";
localizedStrings["After one year"] = "Efter et år";
localizedStrings["Manually"] = "Manuelt";
localizedStrings["Save downloaded files to:"] = "Arkiver overførte arkiver i:";
localizedStrings["Other…"] = "Andet…";
localizedStrings["Always prompt before downloading"] = "Spørg altid før overførsel";
localizedStrings["Prompting cannot be disabled for some high-risk file types, including applications."] = "Spørgsmål kan ikke slås fra med visse risikable arkivtyper, inklusive programmer.";
localizedStrings["Remove download list items:"] = "Slet overførselsliste:";
localizedStrings["When Safari Quits"] = "Når Safari sluttes";
localizedStrings["Upon Successful Download"] = "Når overførslen er gennemført";
localizedStrings["Open “safe” files after downloading"] = "Åbn “sikre” arkiver efter overførsel";
localizedStrings["“Safe” files include movies, pictures, sounds, PDF and text documents, and disk images and other archives."] = "Omfatter bl.a. film, billeder, lyde, PDF- og tekstdokumenter, diskbilleder og andre arkiver.";
localizedStrings["Open links from applications:"] = "Åbn henvisninger fra programmer:";
localizedStrings["in a new window"] = "i et nyt vindue";
localizedStrings["in a new tab in the current window"] = "i en ny fane i det aktuelle vindue";
localizedStrings["This applies to links from Mail, iChat, etc."] = "Dette gælder for henvisninger fra Mail, iChat etc.";
localizedStrings["This applies to links from Mail, etc."] = "Dette gælder for henvisninger fra Mail osv.";

localizedStrings["Reset Safari"] = "Nulstil Safari";
localizedStrings["Are you sure you want to reset Safari?"] = "Er du sikker på, at du vil nulstille Safari?";
localizedStrings["Select the items you want to reset, and then click Reset. You can’t undo this operation."] = "Vælg de emner, du vil nulstille, og klik derefter på Nulstil. Du kan ikke fortryde denne handling.";
localizedStrings["Clear history"] = "Slet historie";
localizedStrings["Reset Top Sites"] = "Nulstil Top Sites";
localizedStrings["Remove all webpage preview images"] = "Fjern alle billedeksempler til websider";
localizedStrings["Empty the cache"] = "Tøm bufferen";
localizedStrings["Clear the Downloads window"] = "Ryd vinduet Overførsler";
localizedStrings["Remove all cookies"] = "Fjern alle cookies";
localizedStrings["Remove all website icons"] = "Fjern alle symboler fra websteder";
localizedStrings["Remove saved names and passwords"] = "Fjern arkiverede navne og adgangskoder";
localizedStrings["Remove other AutoFill form text"] = "Fjern anden auto-udfyldt formulartekst";
localizedStrings["Close all Safari windows"] = "Luk alle Safarivinduer";
localizedStrings["Reset"] = "Nulstil";

localizedStrings["RSS"] = "RSS";
localizedStrings["Default RSS reader:"] = "RSS-standardlæser:";
localizedStrings["Automatically update articles in:"] = "Opdater automatisk artikler i:";
localizedStrings["Bookmarks bar"] = "Bogmærkelinje";
localizedStrings["Bookmarks menu"] = "Bogmærkemenu";
localizedStrings["Check for updates:"] = "Søg efter opdateringer:";
localizedStrings["Never"] = "Aldrig";
localizedStrings["Every day"] = "Hver dag";
localizedStrings["Every hour"] = "Hver time";
localizedStrings["Every 30 minutes"] = "Hver halve time";
localizedStrings["Mark articles as read:"] = "Marker artikler som læst:";
localizedStrings["After viewing the RSS page"] = "Efter gennemsyn af RSS-siden";
localizedStrings["After clicking them"] = "Efter klik på dem";
localizedStrings["Highlight unread articles"] = "Fremhæv ulæste artikler";
localizedStrings["Remove articles:"] = "Fjern artikler:";
localizedStrings["Remove Now"] = "Fjern nu";

localizedStrings["Security"] = "Sikkerhed";
localizedStrings["Fraudulent sites:"] = "Bedrageriske websteder:";
localizedStrings["Warn when visiting a fraudulent website"] = "Advar når et bedragerisk websted besøges";
localizedStrings["The Google Safe Browsing Service is unavailable."] = "Google Safe Browsing Service er ikke tilgængelig.";
localizedStrings["No updates have occurred in %@."] = "Der er ingen opdateringer i %@.";
localizedStrings["Web content:"] = "Webindhold:";
localizedStrings["Enable plug-ins"] = "Slå tilbehør til";
localizedStrings["Enable Java"] = "Slå Java til";
localizedStrings["Enable JavaScript"] = "Slå JavaScript til";
localizedStrings["Block pop-up windows"] = "Bloker ekstra vinduer";
localizedStrings["Accept cookies:"] = "Accepter cookies:";
localizedStrings["Always"] = "Altid";
localizedStrings["Only from sites I visit"] = "Kun fra steder jeg besøger";
localizedStrings["Block cookies from third parties and advertisers."] = "Bloker cookies fra tredjeparter og annoncører.";
localizedStrings["Show Cookies"] = "Vis cookies";
localizedStrings["Default space for database storage:"] = "Standardplads til opbevaring af database:";
localizedStrings["Show Databases"] = "Vis databaser";
localizedStrings["Ask before sending a non-secure form to a secure website"] = "Spørg, før der sendes en usikker formular til et sikkert websted.";

localizedStrings["1 minute"] = "1 minut";
localizedStrings["%@ minutes"] = "%@ minutter";
localizedStrings["1 hour"] = "1 time";
localizedStrings["%@ hours"] = "%@ timer";
localizedStrings["1 day"] = "1 dag";
localizedStrings["%@ days"] = "%@ dage";
        
localizedStrings["Tabs"] = "Faner";
localizedStrings["Ctrl-click opens a link in a new tab"] = "Ctrl-klik åbner en henvisning i en ny fane";
localizedStrings["When a new tab or window opens, make it active."] = "Gør nye faner eller vinduer aktive, når de åbnes.";
localizedStrings["Confirm before closing multiple tabs or windows."] = "Bekræft, når flere faner eller vinduer lukkes.";
localizedStrings["Ctrl-click:"] = "Ctrl-klik:";
localizedStrings["Opens a link in a new tab, and makes it the active tab."] = "Åbner en henvisning i en ny fane og gør den til den aktive fane.";
localizedStrings["Opens a link in a new tab."] = "Åbner en henvisning i en ny fane.";
localizedStrings["Opens a link in a new window, and makes it the active window."] = "Åbner en henvisning i et nyt vindue og gør det til det aktive vindue.";
localizedStrings["Opens a link in a new window."] = "Åbner en henvisning i et nyt vindue.";
localizedStrings["Ctrl-Shift-click:"] = "Ctrl–Skift-klik:";
localizedStrings["Ctrl-Alt-click:"] = "Ctrl-Alt-klik:";
localizedStrings["Ctrl-Alt-Shift-click:"] = "Ctrl-Alt-Skift-klik:";

localizedStrings["Name:"] = "Navn:";
localizedStrings["Password:"] = "Adgangskode:";
localizedStrings["Remember this password"] = "Husk adgangskoden";
localizedStrings["Log In"] = "Log ind";

localizedStrings["File Download - Security Warning"] = "Arkivoverførsel – sikkerhedsadvarsel";
localizedStrings["Do you want to open or save this file?"] = "Vil du åbne eller arkivere dette arkiv?";
localizedStrings["Always ask before downloading files of this type"] = "Spørg altid før overførsel af denne type arkiver";
localizedStrings["Open"] = "Åbn";
localizedStrings["Save"] = "Arkiver";
localizedStrings["Name:"] = "Navn:";
localizedStrings["Type:"] = "Type:";
localizedStrings["From:"] = "Fra:";

localizedStrings["Type a name for the bookmark, and choose where to keep it."] = "Skriv et navn til bogmærket, og vælg, hvor det skal arkiveres.";
localizedStrings["Add"] = "Tilføj";

localizedStrings["Spelling and Grammar"] = "Stavekontrol og grammatik";
localizedStrings["Ignore"] = "Ignorer";
localizedStrings["Learn"] = "Husk";
localizedStrings["Find Next"] = "Find næste";
localizedStrings["Change"] = "Skift";
localizedStrings["Check grammar"] = "Grammatikkontrol";

localizedStrings["Choose a Font"] = "Vælg en skrift";
localizedStrings["Family"] = "Familie";
localizedStrings["Sample"] = "Eksempel";
localizedStrings["ABCDEFGHIJKLMNOPQRSTUVWXYZ"] = "ABCDEFGHIJKLMNOPQRSTUVWXYZÆØÅ";
localizedStrings["abcdefghijklmnopqrstuvwxyz"] = "abcdefghijklmnopqrstuvwxyzæøå";
localizedStrings["1234567890"] = "1234567890";
localizedStrings["Size"] = "Størrelse";

localizedStrings["Drag your favorite items into the toolbar…"] = "Træk dine favoritemner til værktøjslinjen…";
localizedStrings["Back/Forward"] = "Tilbage/frem";
localizedStrings["Top Sites"] = "Top Sites";
localizedStrings["Home"] = "Hjem";
localizedStrings["Zoom"] = "Zoom";
localizedStrings["Stop/Reload"] = "Stop/genindlæs";
localizedStrings["Add Bookmark"] = "Tilføj bogmærke";
localizedStrings["Print"] = "Udskriv";
localizedStrings["Address and Search"] = "Adresse og søgning";
localizedStrings["Add Bookmark, Address and Search"] = "Tilføj bogmærke, adresse og søgning.";
localizedStrings["…or drag the default set."] = "… eller træk standardsættet.";
localizedStrings["New Tab"] = "Ny fane";
localizedStrings["History"] = "Historie";
localizedStrings["Bookmarks"] = "Bogmærker";
localizedStrings["Add Bookmark"] = "Tilføj bogmærke";
localizedStrings["Bookmarks Bar"] = "Bogmærkelinje";
localizedStrings["Mail"] = "Mail";
localizedStrings["Downloads"] = "Overførsler";
localizedStrings["Web Inspector"] = "Webinfo";

localizedStrings["Warning: Visiting this site may harm your computer"] = "Advarsel: Besøg på dette websted kan skade computeren";
localizedStrings["Warning: Suspected phishing site"] = "Advarsel: Websted mistænkt for phishing";
localizedStrings["The website you are visiting appears to contain malware. Malware is malicious software that may harm your computer or otherwise operate without your consent. Your computer can be infected just by browsing to a site with malware, without any further action on your part."] = "Det websted, du besøger, indeholder tilsyneladende ondsindet software. Ondsindet software (såkaldt malware) kan beskadige computeren eller udføre handlinger uden din viden. Computeren kan blive inficeret ved, at du blot besøger et sted med ondsindet software, uden at du udfører nogen andre handlinger.";
localizedStrings["For detailed information about problems found on this site, or a portion of this site, visit the Google Safe Browsing diagnostic page for %@."] = "Der findes udførlige oplysninger om problemer, der er fundet på dette websted eller på en del af webstedet, på Google Safe Browsing-diagnostiksiden til %@.";
localizedStrings["The website you are visiting has been reported as a “phishing” website. These websites are designed to trick you into disclosing personal or financial information, usually by creating a copy of a legitimate website, such as a bank."] = "Det websted, du besøger, er blevet indberettet som et “phishing-websted”. Disse websteder prøver at narre dig til at afsløre personlige eller økonomiske oplysninger, som regel vha. en kopi af et ægte websted, f.eks. en kopi af en banks websted.";
localizedStrings["Learn more about phishing scams"] = "Læs mere om phishing-svindel";
localizedStrings["Ignore warning"] = "Ignorer advarsel";
localizedStrings["Go Back"] = "Tilbage";
localizedStrings["Close page"] = "Luk side";
localizedStrings["Report an error"] = "Rapporter en fejl";
localizedStrings["Suspected Phishing Site"] = "Websted mistænkt for phishing";
localizedStrings["Suspected Malware Site"] = "Websted mistænkt for ondsindet software";

localizedStrings["No matches"] = "Ingen resultater";
localizedStrings["1 match"] = "1 svar";
localizedStrings["%@ matches"] = "%@ svar";
localizedStrings["All"] = "Alle";
localizedStrings["Search:"] = "Søg:";
