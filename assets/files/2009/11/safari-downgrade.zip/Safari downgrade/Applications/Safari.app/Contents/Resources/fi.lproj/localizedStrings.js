﻿







var localizedStrings = new Object;

localizedStrings["About Safari"] = "Tietoja: Safari";
localizedStrings["Copyright © 2007-2009 Apple Inc. All rights reserved."] = "Copyright © 2007 - 2009 Apple Inc. Kaikki oikeudet pidätetään.";

localizedStrings["Advanced"] = "Lisävalinnat";
localizedStrings["Universal Access:"] = "Käyttöapu:";
localizedStrings["Never use font sizes smaller than"] = "Älä käytä pienempiä kirjainkokoja kuin";
localizedStrings["Press Tab to highlight each item on a webpage"] = "Korosta verkkosivun jokainen kohde \npainamalla sarkainnäppäintä";
localizedStrings["Style sheet:"] = "Tyylisivu:";
localizedStrings["Proxies:"] = "Välipalvelimet:";
localizedStrings["Open the Internet Options Control Panel to change your proxy settings"] = "Muuta välipalvelinasetuksia avaamalla Internet-asetusten säädin";
localizedStrings["Change Settings…"] = "Muuta asetuksia…";
localizedStrings["Show Develop menu in menu bar"] = "Näytä Kehitys-valikko valikkorivillä";

localizedStrings["Cancel"] = "Kumoa";
localizedStrings["Done"] = "Valmis";

localizedStrings["Appearance"] = "Ulkoasu";
localizedStrings["Standard font:"] = "Vakiokirjasin:";
localizedStrings["Select the font to use when a web page doesn’t specify a font."] = "Valitse kirjasin, jota käytetään, kun verkkosivu ei määrittele kirjasinta.";
localizedStrings["Select…"] = "Valitse…";
localizedStrings["Fixed-width font:"] = "Tasavälinen kirjasin:";
localizedStrings["Select the font to use when a web page specifies a fixed-width font."] = "Valitse kirjasin, jota käytetään, kun verkkosivu määrittelee tasavälisen kirjasimen.";
localizedStrings["Font smoothing:"] = "Kirjasinten pehmennys:";

localizedStrings["Best for CRT"] = "Paras kuvaputkinäytölle";
localizedStrings["Light"] = "Kevyt";
localizedStrings["Medium - best for Flat Panel"] = "Keskinkertainen - paras LCD-näytöille";
localizedStrings["Strong"] = "Voimakas";
localizedStrings["Windows Standard"] = "Windows-standardi";
localizedStrings["Display images when the page opens"] = "Näytä kuvat sivun avautuessa";
localizedStrings["Default encoding:"] = "Oletuskoodaus:";

localizedStrings["AutoFill"] = "Autom. täyttö";
localizedStrings["AutoFill web forms:"] = "Täytä verkkolomakkeisiin automaattisesti:";
localizedStrings["Using info from my Address Book card"] = "Käyttäen osoitekirjakorttia";
localizedStrings["Open Address Book to edit your card"] = "Avaa Osoitekirja muokataksesi korttia";
localizedStrings["Edit…"] = "Muokkaa…";
localizedStrings["User names and passwords"] = "Tunnukset ja salasanat";
localizedStrings["Remove saved names and passwords"] = "Poista tallennetut nimet ja salasanat";
localizedStrings["Other forms"] = "Muut lomakkeet";
localizedStrings["Remove websites with saved AutoFill information"] = "Poista verkkosivustot, joilla on tallennettuja, automaattisesti täytettyjä tietoja";

localizedStrings["Bookmark Chooser"] = "Kirjanmerkkivalitsin";
localizedStrings["Choose a folder or collection"] = "Valitse kansio tai kokoelma";
localizedStrings["Choose"] = "Valitse";

localizedStrings["Bookmarks"] = "Kirjanmerkit";
localizedStrings["Bookmarks bar:"] = "Kirjanmerkkipalkki:";
localizedStrings["Include Address Book"] = "Sisällytä Osoitekirja";
localizedStrings["Include Bonjour"] = "Sisällytä Bonjour";
localizedStrings["Bookmarks menu:"] = "Kirjanmerkkivalikko:";
localizedStrings["Include bookmarks bar"] = "Sisällytä kirjanmerkkipalkki";
localizedStrings["Collections:"] = "Kokoelmat:";
localizedStrings["Synchronize bookmarks using MobileMe"] = "Synkronoi kirjanmerkit MobileMellä";
localizedStrings["MobileMe…"] = "MobileMe…";

localizedStrings["Type a name for the bookmark."] = "Kirjoita kirjanmerkille nimi.";
localizedStrings["OK"] = "OK";

localizedStrings["Report Bug"] = "Raportoi bugi";
localizedStrings["Page Address:"] = "Sivun osoite:";
localizedStrings["Description:"] = "Kuvaus:";
localizedStrings["Problem type:"] = "Ongelmatyyppi:";
localizedStrings["Unspecified"] = "Määrittelemätön";
localizedStrings["Crash"] = "Kaatuminen";
localizedStrings["Can’t log in"] = "Ei voida kirjautua";
localizedStrings["Can’t load page"] = "Sivua ei voida ladata";
localizedStrings["Blank page"] = "Tyhjä sivu";
localizedStrings["Content missing"] = "Sisältöä puuttuu";
localizedStrings["Behavior wrong"] = "Väärä käytös";
localizedStrings["Appearance wrong"] = "Väärä ulkoasu";
localizedStrings["Other problem"] = "Muu ongelma";
localizedStrings["Send screen shot of current page"] = "Lähetä kuvakaappaus nykyisestä sivusta";
localizedStrings["Send source of current page"] = "Lähetä nykyisen sivun lähdekoodi";

localizedStrings["General"] = "Yleiset";
localizedStrings["Default web browser:"] = "Oletusselain:";
localizedStrings["Default search engine:"] = "Oletushakukone:";
localizedStrings["Google"] = "Google";
localizedStrings["Yahoo!"] = "Yahoo!";
localizedStrings["New windows open with:"] = "Näytä uudessa ikkunassa:";
localizedStrings["New tabs open with:"] = "Näytä uudella välilehdellä:";
localizedStrings["Home Page"] = "Kotisivu";
localizedStrings["Empty Page"] = "Tyhjä sivu";
localizedStrings["Same Page"] = "Sama sivu";
localizedStrings["Bookmarks"] = "Kirjanmerkit";
localizedStrings["Choose tabs folder…"] = "Valitse välilehtikansio…";
localizedStrings["Home page:"] = "Kotisivu:";
localizedStrings["Set to Current Page"] = "Aseta nykyiselle sivulle";
localizedStrings["Remove history items:"] = "Poista historiakohteet:";
localizedStrings["After one day"] = "Päivän jälkeen";
localizedStrings["After one week"] = "Viikon jälkeen";
localizedStrings["After two weeks"] = "Kahden viikon jälkeen";
localizedStrings["After one month"] = "Kuukauden jälkeen";
localizedStrings["After one year"] = "Vuoden jälkeen";
localizedStrings["Manually"] = "Käsin";
localizedStrings["Save downloaded files to:"] = "Tallenna ladatut tiedostot kansioon:";
localizedStrings["Other…"] = "Muu…";
localizedStrings["Always prompt before downloading"] = "Kysy aina ennen lataamista";
localizedStrings["Prompting cannot be disabled for some high-risk file types, including applications."] = "Kyselyä tiedostojen lataamisesta ei voida estää suuren riskitason tiedostotyypeille, mukaan lukien ohjelmat.";
localizedStrings["Remove download list items:"] = "Poista ladatut kohteet luettelosta:";
localizedStrings["When Safari Quits"] = "Kun Safari lopetetaan";
localizedStrings["Upon Successful Download"] = "Onnistuneen tiedostolatauksen jälkeen";
localizedStrings["Open “safe” files after downloading"] = "Avaa ”turvalliset” tiedostot lataamisen jälkeen";
localizedStrings["“Safe” files include movies, pictures, sounds, PDF and text documents, and disk images and other archives."] = "”Turvallisilla” tiedostoilla tarkoitetaan elokuvia, kuvia, ääniä, PDF- ja tekstidokumentteja sekä levytiedostoja ja muita arkistoja.";
localizedStrings["Open links from applications:"] = "Avaa sovellusten linkit:";
localizedStrings["in a new window"] = "Uudessa ikkunassa";
localizedStrings["in a new tab in the current window"] = "Uudella välilehdellä nykyisessä ikkunassa";
localizedStrings["This applies to links from Mail, iChat, etc."] = "Tämä koskee mm. Mailin ja iChatin linkkejä.";
localizedStrings["This applies to links from Mail, etc."] = "Tämä koskee mm. Mailin linkkejä.";

localizedStrings["Reset Safari"] = "Nollaa Safari";
localizedStrings["Are you sure you want to reset Safari?"] = "Haluatko varmasti nollata Safarin?";
localizedStrings["Select the items you want to reset, and then click Reset. You can’t undo this operation."] = "Valitse kohteet, jotka haluat nollata, ja osoita Nollaa. Toimintoa ei voida perua.";
localizedStrings["Clear history"] = "Tyhjennä historia";
localizedStrings["Reset Top Sites"] = "Nollaa Top Sites -seinä";
localizedStrings["Remove all webpage preview images"] = "Poista kaikki verkkosivujen esikatselukuvat";
localizedStrings["Empty the cache"] = "Tyhjennä välimuisti";
localizedStrings["Clear the Downloads window"] = "Tyhjennä Lataukset-ikkuna";
localizedStrings["Remove all cookies"] = "Poista kaikki evästeet";
localizedStrings["Remove all website icons"] = "Poista kaikki sivustojen symbolit";
localizedStrings["Remove saved names and passwords"] = "Poista tallennetut nimet ja salasanat";
localizedStrings["Remove other AutoFill form text"] = "Poista muut automaattisesti täytetyt lomaketekstit";
localizedStrings["Close all Safari windows"] = "Sulje kaikki Safari-ikkunat";
localizedStrings["Reset"] = "Nollaa";

localizedStrings["RSS"] = "RSS";
localizedStrings["Default RSS reader:"] = "Oletusarvoinen RSS-ohjelma:";
localizedStrings["Automatically update articles in:"] = "Päivitä artikkelit automaattisesti:";
localizedStrings["Bookmarks bar"] = "Kirjanmerkkipalkissa";
localizedStrings["Bookmarks menu"] = "Kirjanmerkkivalikossa";
localizedStrings["Check for updates:"] = "Tarkista päivitykset:";
localizedStrings["Never"] = "Ei koskaan";
localizedStrings["Every day"] = "Päivittäin";
localizedStrings["Every hour"] = "Tunnin välein";
localizedStrings["Every 30 minutes"] = "30 minuutin välein";
localizedStrings["Mark articles as read:"] = "Merkitse artikkelit luetuiksi:";
localizedStrings["After viewing the RSS page"] = "RSS-sivun katselemisen jälkeen";
localizedStrings["After clicking them"] = "Osoittamisen jälkeen";
localizedStrings["Highlight unread articles"] = "Korosta lukemattomat artikkelit";
localizedStrings["Remove articles:"] = "Poista artikkelit:";
localizedStrings["Remove Now"] = "Poista nyt";

localizedStrings["Security"] = "Suojaus";
localizedStrings["Fraudulent sites:"] = "Vilpilliset sivustot:";
localizedStrings["Warn when visiting a fraudulent website"] = "Varoita käytäessä vilpillisellä verkkosivustolla";
localizedStrings["The Google Safe Browsing Service is unavailable."] = "Googlen Safe Browsing -palvelu ei ole saatavilla.";
localizedStrings["No updates have occurred in %@."] = "Ei uusia päivityksiä ajassa %@.";
localizedStrings["Web content:"] = "Verkkosisältö:";
localizedStrings["Enable plug-ins"] = "Salli liitännäiset";
localizedStrings["Enable Java"] = "Salli Java";
localizedStrings["Enable JavaScript"] = "Salli JavaScript";
localizedStrings["Block pop-up windows"] = "Estä ponnahdusikkunat";
localizedStrings["Accept cookies:"] = "Hyväksy evästeet:";
localizedStrings["Always"] = "Aina";
localizedStrings["Only from sites I visit"] = "Vain sivustoilta, joilla käyn";
localizedStrings["Block cookies from third parties and advertisers."] = "Estä muiden toimijoiden ja mainostajien evästeet.";
localizedStrings["Show Cookies"] = "Näytä evästeet";
localizedStrings["Default space for database storage:"] = "Tietokantojen tallennustilan oletuskoko:";
localizedStrings["Show Databases"] = "Näytä tietokannat";
localizedStrings["Ask before sending a non-secure form to a secure website"] = "Kysy ennen ei-suojatun lomakkeen lähetystä suojatulle sivustolle";

localizedStrings["1 minute"] = "1 minuutti";
localizedStrings["%@ minutes"] = "%@ minuuttia";
localizedStrings["1 hour"] = "1 tunti";
localizedStrings["%@ hours"] = "%@ tuntia";
localizedStrings["1 day"] = "1 päivä";
localizedStrings["%@ days"] = "%@ päivää";
        
localizedStrings["Tabs"] = "Välilehdet";
localizedStrings["Ctrl-click opens a link in a new tab"] = "Ctrl-osoitus avaa linkin uudella välilehdellä";
localizedStrings["When a new tab or window opens, make it active."] = "Valitse uusi välilehti tai ikkuna sellaisen avautuessa.";
localizedStrings["Confirm before closing multiple tabs or windows."] = "Kysy ennen useiden välilehtien ja ikkunoiden sulkemista.";
localizedStrings["Ctrl-click:"] = "Ctrl-osoita:";
localizedStrings["Opens a link in a new tab, and makes it the active tab."] = "Avaa linkin uudella välilehdellä ja valitsee sen.";
localizedStrings["Opens a link in a new tab."] = "Avaa linkin uudella välilehdellä.";
localizedStrings["Opens a link in a new window, and makes it the active window."] = "Avaa linkin uudessa ikkunassa ja valitsee sen.";
localizedStrings["Opens a link in a new window."] = "Avaa linkin uudessa ikkunassa.";
localizedStrings["Ctrl-Shift-click:"] = "Ctrl-vaihto-osoita:";
localizedStrings["Ctrl-Alt-click:"] = "Ctrl-alt-osoita:";
localizedStrings["Ctrl-Alt-Shift-click:"] = "Ctrl-alt-vaihto-osoita:";

localizedStrings["Name:"] = "Nimi:";
localizedStrings["Password:"] = "Salasana:";
localizedStrings["Remember this password"] = "Muista salasana";
localizedStrings["Log In"] = "Kirjaudu sisään";

localizedStrings["File Download - Security Warning"] = "Tiedostolataus - suojausvaroitus";
localizedStrings["Do you want to open or save this file?"] = "Haluatko avata tai tallentaa tiedoston?";
localizedStrings["Always ask before downloading files of this type"] = "Kysy aina ennen kuin tämäntyyppisiä tiedostoja ladataan";
localizedStrings["Open"] = "Avaa";
localizedStrings["Save"] = "Tallenna";
localizedStrings["Name:"] = "Nimi:";
localizedStrings["Type:"] = "Tyyppi:";
localizedStrings["From:"] = "Mistä:";

localizedStrings["Type a name for the bookmark, and choose where to keep it."] = "Valitse kirjanmerkin nimi ja paikka.";
localizedStrings["Add"] = "Lisää";

localizedStrings["Spelling and Grammar"] = "Oikeinkirjoitus ja kielioppi";
localizedStrings["Ignore"] = "Älä huomioi";
localizedStrings["Learn"] = "Opi";
localizedStrings["Find Next"] = "Etsi seuraava";
localizedStrings["Change"] = "Muuta";
localizedStrings["Check grammar"] = "Tarkista kielioppi";

localizedStrings["Choose a Font"] = "Valitse kirjasin:";
localizedStrings["Family"] = "Perhe";
localizedStrings["Sample"] = "Näyte";
localizedStrings["ABCDEFGHIJKLMNOPQRSTUVWXYZ"] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
localizedStrings["abcdefghijklmnopqrstuvwxyz"] = "abcdefghijklmnopqrstuvwxyz";
localizedStrings["1234567890"] = "1234567890";
localizedStrings["Size"] = "Koko";

localizedStrings["Drag your favorite items into the toolbar…"] = "Vedä halutut kohteet työkalupalkkiin…";
localizedStrings["Back/Forward"] = "Taakse/Eteen";
localizedStrings["Top Sites"] = "Top Sites";
localizedStrings["Home"] = "Koti";
localizedStrings["Zoom"] = "Zoomaa";
localizedStrings["Stop/Reload"] = "Pysäytä/Lataa uudelleen";
localizedStrings["Add Bookmark"] = "Lisää kirjanmerkki";
localizedStrings["Print"] = "Tulosta";
localizedStrings["Address and Search"] = "Osoite ja haku";
localizedStrings["Add Bookmark, Address and Search"] = "Lisää kirjanmerkki, osoite ja haku";
localizedStrings["…or drag the default set."] = "…tai vedä oletuskokoonpano.";
localizedStrings["New Tab"] = "Uusi välilehti";
localizedStrings["History"] = "Historia";
localizedStrings["Bookmarks"] = "Kirjanmerkit";
localizedStrings["Add Bookmark"] = "Lisää kirjanmerkki";
localizedStrings["Bookmarks Bar"] = "Kirjanmerkkipalkki";
localizedStrings["Mail"] = "Lähetä";
localizedStrings["Downloads"] = "Lataukset";
localizedStrings["Web Inspector"] = "Verkkoinspektori";

localizedStrings["Warning: Visiting this site may harm your computer"] = "Varoitus: vierailu tällä sivustolla saattaa vahingoittaa tietokonettasi";
localizedStrings["Warning: Suspected phishing site"] = "Varoitus: mahdollinen verkkourkintasivusto";
localizedStrings["The website you are visiting appears to contain malware. Malware is malicious software that may harm your computer or otherwise operate without your consent. Your computer can be infected just by browsing to a site with malware, without any further action on your part."] = "Vierailemasi sivusto näyttää sisältävän haittaohjelman. Haittaohjelmat ovat ohjelmistoja, jotka saattavat vahingoittaa tietokonetta tai muutoin toimia ilman suostumustasi. Tietokoneesi voi saastua pelkästään käymällä haittaohjelman sisältävällä sivustolla, ilman että teet mitään muuta.";
localizedStrings["For detailed information about problems found on this site, or a portion of this site, visit the Google Safe Browsing diagnostic page for %@."] = "Lisätietoja tältä sivustolta, tai osasta sivustoa, löydetyistä ongelmista löytyy Google Safe Browsing -diagnostiikkasivulta kohteelle %@.";
localizedStrings["The website you are visiting has been reported as a “phishing” website. These websites are designed to trick you into disclosing personal or financial information, usually by creating a copy of a legitimate website, such as a bank."] = "Käymäsi sivusto on raportoitu ”verkkourkintasivustoksi”. Nämä sivustot yrittävät huijata kävijää paljastamaan taloudellisia tai henkilökohtaisia tietoja, tavallisesti luomalla kopion luotettavasta sivustosta, esimerkiksi pankin verkkosivustosta.";
localizedStrings["Learn more about phishing scams"] = "Lisätietoja verkkourkintahuijauksista";
localizedStrings["Ignore warning"] = "Älä huomioi varoitusta";
localizedStrings["Go Back"] = "Takaisin";
localizedStrings["Close page"] = "Sulje sivu";
localizedStrings["Report an error"] = "Raportoi virhe";
localizedStrings["Suspected Phishing Site"] = "Mahdollinen verkkourkintasivusto";
localizedStrings["Suspected Malware Site"] = "Mahdollinen haittaohjelmasivusto";

localizedStrings["No matches"] = "Ei osumia";
localizedStrings["1 match"] = "1 osuma";
localizedStrings["%@ matches"] = "%@ osumaa";
localizedStrings["All"] = "Kaikki";
localizedStrings["Search:"] = "Hae:";
